# tk01.py
import tkinter as tk

def main():
      # Cria a janela
      janela = tk.Tk()
      janela.title('Primeira janela')
      
      # Entra no mainloop, o que faz com que 
      # a janela seja renderizada na tela
      janela.mainloop()

main()
